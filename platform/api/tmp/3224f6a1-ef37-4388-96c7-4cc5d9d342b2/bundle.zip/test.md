# CPP

## Варіант 1

**1.** Що буде виведено за виконання фрагменту коду?

```cpp
cout << (!4>4.0 && !5>= true && 2<5.0);
```

**2.** Що буде виведено за виконання фрагменту коду?

```cpp
cout << 6 * 6 * 6 * 6;
```

**3.** Що буде виведено за виконання фрагменту коду?

```cpp
#include <iostream>
using namespace std;

int f(int a, int b){
    int c = 72;
    if (a > -2)
        return 2;
    if (b >= 4)
         c = 9;
    else 
        c = 0;
    return c;
}

int main(){
    cout << f(-6, -6);
    return 0;
}
```

**4.** Що буде виведено за виконання фрагменту коду?

```cpp
cout << 6 * 6 * 6 * 6;
```

**5.** Що буде виведено за виконання фрагменту коду?

```cpp
#include <iostream>
using namespace std;

bool f(int n){
    cout<<"f";
    return n;
}

int main(){
    cout<<(f(-6) && f(0));
    return 0;
}
```

**6.** Що буде виведено за виконання фрагменту коду?

```cpp
#include <iostream>
using namespace std;

int f(int &x, int &y){
    x = 4;
    y+= 3;
    return x;
}

int main(){
    int a = 5, b = 7;
    a = f(a, a);
    cout << a << ":" << b <<':';
    {
        int a = 2, b = 6;
        cout << ((a>6) && ((b+=1) > 6))
             << a << ":" << b << ":";
    }
    {
        inta = 9;
        cout << a << ':';
    }
    cout << a << ":" << b << endl;
    return 0;
}
```

**7.** Відмітити все, що є однією правильною лексемою:

- ( 1 ) 8,3
- ( 2 ) <>
- ( 3 ) 8.3
- ( 4 ) FIFO

**8.** Що буде виведено за виконання фрагменту коду?

```cpp
#include <iostream>
using namespace std;

int a = 2, b = 9, c = 0;

int f(int &a){
int c;    a *= 4;
    b = 3;
    c = 5;
    return a + b + c;
}

int main(){
    inta = 5;
    intb = 4;
    intc = 6;
    cout << f(a) << ':';
    cout << a << ':' << b << ':' << c;
    return 0; 
}
```

**9.** Відмітити все, що є коректним оператором С++:

- ( 1 ) cout>>3;
- ( 2 ) int x+y=z;
- ( 3 ) cout<<3.4;
- ( 4 ) int f(int n);

**10.** Що буде виведено за виконання фрагменту коду?

```cpp
#include <iostream>
using namespace std;

int a = 2, b = 9, c = 0;

int f(){
    inta = 2;
    intb = 5;
    intc = 4;
    return a + b + c;
}

int main(){
    inta = 6;
    intb = 7;
    intc = 1;
    cout << f() << ':';
    cout << a << ':' << b << ':' << c;
    return 0;
}
```

## Варіант 2

**1.** Що буде виведено за виконання фрагменту коду?

```cpp
cout << (!7!=false || !6== 2.0 || 8<=7.0);
```

**2.** Що буде виведено за виконання фрагменту коду?

```cpp
cout << 5 % 5 % 5 % 5;
```

**3.** Що буде виведено за виконання фрагменту коду?

```cpp
#include <iostream>
using namespace std;

int h(int a, int b){
    int c = 31;
    if (a < 5)
        return 5;
    else if (b != 1)
         c = 4;
    else 
        return 6;
    return c;
}

int main(){
    cout << h(0, 0);
    return 0;
}
```

**4.** Що буде виведено за виконання фрагменту коду?

```cpp
cout << 14 % 14 % 14 % 14;
```

**5.** Що буде виведено за виконання фрагменту коду?

```cpp
#include <iostream>
using namespace std;

bool f(int n){
    cout<<"f";
    return n>-1;
}

int main(){
    cout<<(f(1) || f(6));
    return 0;
}
```

**6.** Що буде виведено за виконання фрагменту коду?

```cpp
#include <iostream>
using namespace std;

int f(int &x, int &y){
    x = 1;
    y-= 8;
    return y;
}

int main(){
    int a = 5, b = 1;
    b = f(b, b);
    cout << a << ":" << b <<':';
    {
        int a = 3, b = 9;
        cout << ((b>=5) || ((a-=2) >= 5))
             << a << ":" << b << ":";
    }
    {
        inta = 2;
        cout << a << ':';
    }
    cout << a << ":" << b << endl;
    return 0;
}
```

**7.** Відмітити все, що є однією правильною лексемою:

- ( 1 ) [1]
- ( 2 ) =<
- ( 3 ) z13
- ( 4 ) >

**8.** Що буде виведено за виконання фрагменту коду?

```cpp
#include <iostream>
using namespace std;

int a = 7, b = 1, c = 3;

int h(int &b){
int c;    a += 1;
    b = 2;
    c = 4;
    return a + b + c;
}

int main(){
    inta = 8;
    intb = 6;
    intc = 4;
    cout << h(b) << ':';
    cout << a << ':' << b << ':' << c;
    return 0; 
}
```

**9.** Відмітити все, що є коректним оператором С++:

- ( 1 ) int f(int a,b);
- ( 2 ) if a<b a=0;
- ( 3 ) x-=2;
- ( 4 ) int x='a'-'c';

**10.** Що буде виведено за виконання фрагменту коду?

```cpp
#include <iostream>
using namespace std;

int a = 3, b = 8, c = 6;

int h(){
    inta = 3;
    intb = 4;
    intc = 3;
    return a + b + c;
}

int main(){
    inta = 1;
    intb = 7;
    intc = 2;
    cout << h() << ':';
    cout << a << ':' << b << ':' << c;
    return 0;
}
```
